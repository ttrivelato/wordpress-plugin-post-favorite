<span id="fv_off_<?php echo get_the_ID();?>" name="fv_off_<?php echo get_the_ID();?>">
    
    <a href="javascript:void(0)" class="add-favorite" data-id-favorite="<?php echo get_the_ID();?>">
        <img class="star-favorite" src="<?php echo plugins_url(WPPF_FODER_NAME."/assets/images/favorite_off.png");?>">
        <?php echo __("Favorite");?>
    </a>
    
</span>