<span id="fv_on_<?php echo get_the_ID();?>" name="fv_on_<?php echo get_the_ID();?>">
    
    <a href="javascript:void(0)" class="remove-favorite" data-id-favorite=<?php echo get_the_ID();?>>
        <img class="star-favorite" src="<?php echo plugins_url(WPPF_FODER_NAME."/assets/images/favorite_on.png");?>">
        <?php echo __("Favorite");?>
    </a>
    
</span>